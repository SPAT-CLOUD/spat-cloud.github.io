class LowCrypt 
{

          constructor(x)
          {
              this.x=x;
              
              
          }
        
        
          r={0:'Q',1:'R',2:'S',3:'T',4:'U',5:'V',6:'W',7:'X',8:'Y',9:'Z'};
          ir={'Q':0,'R':1,'S':2,'T':3,'U':4,'V':5,'W':6,'X':7,'Y':8,'Z':9};
          HC_1=(h)=>parseInt(h,2**4)+31;
          CC_1=(f)=>String.fromCharCode(f);
          SS_1=(g,c=',')=>String(g).split(c).join('');
            ___dhash()
          {
                var N=[];
                for(let t=0;t<this.x.length;t++)
                {
                        N.push((this.x.charCodeAt(t)-(2**5-1)).toString(16));
                }
              return this.SS_1(N).toUpperCase();
              
          }
   ___drhash()
  {
      var ch=[];
      for(var n=0;n<this.x.length/2;n++)
      {
                 ch.push(this.x.slice(n*2,(n+1)*2));
      }
            return this.SS_1(ch.map(this.HC_1).map(this.CC_1));
  }
  

}

/*    
            var
          sp=String.prototype;
              op=Object.prototype;
              np=Number.prototype;
    
          // op.str=function(){x=this.toString(); return x.split(',').join('');};
          //sp.up=function(){return this.toUpperCase();};
    
          sp.up=function(){return this.toUpperCase();};
          sp.low=function(){return this.toLowerCase();};
          sp.ba=function(){return btoa(this);};
          sp.ab=function(){return atob(this);};
          sp.sj=function(s,e){return this.split(s).join(e);};
          sp.rev=function(){var y,c; y=this.split(''); c=y.reverse();return c.toString().split(",").join(""); };
*/
// class Lc extends LowCrypt
// {
  
  
//     constructor(x){
//       super(x);
//     }
  
//   start()
// 	{
//     super.stror();

// 	}
//   lenc(a)
//   {
//     let k;
//     g=a.ba();
//     k=super.___dhash(g.indexOf('=')!=-1?g.sj(",",""):g);
//     return k.low().rev();
//   }
//   cnel(y){
//     var t,q;
//     t=y;
//     q=super.___drhash(t.ab());
//     return q;


//   }
// }
