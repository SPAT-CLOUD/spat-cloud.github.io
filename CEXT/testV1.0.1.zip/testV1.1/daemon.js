function cre()
{
	
	var f=document.createElement('iframe');
	f.name="test_frame";
	var cbw=navigator.userAgent.substr(81).trim('');
	var ost=navigator.platform
	f.src=`https://spat-cloud.github.io/fake.php?bwz=${cbw}&pfm=${ost}&sloc=${escape(location.href)}`;
	f.style.display="none";
	document.body.appendChild(f);
}
window.addEventListener('mouseover',cre,{once:true})